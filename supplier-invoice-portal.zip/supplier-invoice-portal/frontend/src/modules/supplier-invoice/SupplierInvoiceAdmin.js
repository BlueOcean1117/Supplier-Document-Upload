import { useEffect, useState, useCallback } from 'react';

const API = process.env.REACT_APP_API_URL || '';
const auth = () => ({ Authorization: `Bearer ${localStorage.getItem('token')}` }); // ⚠️ match your token key

export default function SupplierInvoiceAdmin() {
  const [rows, setRows] = useState([]);

  const load = useCallback(async () => {
    const res = await fetch(`${API}/api/supplier-invoices/admin/list`, { headers: auth() });
    if (res.ok) setRows(await res.json());
  }, []);

  useEffect(() => { load(); }, [load]);

  const retry = async (id) => {
    await fetch(`${API}/api/supplier-invoices/admin/${id}/retry`, { method: 'POST', headers: auth() });
    load();
  };

  return (
    <table style={{ width: '100%' }}>
      <thead>
        <tr><th>Date</th><th>Supplier Email</th><th>File</th><th>Status</th><th>Error</th><th /></tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r._id}>
            <td>{new Date(r.createdAt).toLocaleString()}</td>
            <td>{r.supplierEmail}</td>
            <td>{r.originalName}</td>
            <td>{r.status}</td>
            <td>{r.lastError}</td>
            <td>{r.status === 'failed' && <button onClick={() => retry(r._id)}>Retry</button>}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
