import { useState } from 'react';

const API = process.env.REACT_APP_API_URL || ''; // ⚠️ match your existing API base

export default function SupplierInvoicePortal() {
  const [email, setEmail] = useState('');
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ type: '', text: '' });

  const submit = async (e) => {
    e.preventDefault();
    const form = e.target;
    setMsg({ type: '', text: '' });
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('supplierEmail', email);
      fd.append('invoice', file);
      const res = await fetch(`${API}/api/supplier-invoices`, { method: 'POST', body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || 'Submission failed');
      setMsg({ type: 'ok', text: data.message });
      setEmail('');
      setFile(null);
      form.reset();
    } catch (err) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ maxWidth: 420, margin: '60px auto', padding: 24 }}>
      <form onSubmit={submit}>
        <label>Supplier Email Address</label>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
               style={{ display: 'block', width: '100%', margin: '6px 0 16px' }} />

        <label>Upload Invoice Document</label>
        <input type="file" required accept=".pdf,.jpg,.jpeg,.png"
               onChange={(e) => setFile(e.target.files[0] || null)}
               style={{ display: 'block', margin: '6px 0 16px' }} />

        <button type="submit" disabled={busy || !file}>{busy ? 'Submitting…' : 'Submit'}</button>
      </form>
      {msg.text && <p style={{ color: msg.type === 'ok' ? 'green' : 'crimson' }}>{msg.text}</p>}
    </div>
  );
}
