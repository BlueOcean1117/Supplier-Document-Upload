# Supplier Invoice Portal — run locally

## Prerequisites
- Node 18+  •  MongoDB running locally (or an Atlas URI)

## 1. Backend
```bash
cd backend
npm install
cp .env.example .env        # then edit .env (SMTP + ADMIN_TOKEN + MONGO_URI)
npm start                   # http://localhost:5000
```

## 2. Frontend (new terminal)
```bash
cd frontend
npm install
npm start                   # http://localhost:3000
```

## 3. Use it
- Supplier page: http://localhost:3000/supplier-invoice
- Admin page:    http://localhost:3000/admin/supplier-invoices
  In the browser console once:  localStorage.setItem('token', '<your ADMIN_TOKEN>')

## Gmail SMTP
SMTP_HOST=smtp.gmail.com, SMTP_PORT=587, SMTP_SECURE=false,
SMTP_PASS = Google App Password (needs 2-Step Verification on).

## Test the API without the UI
```bash
curl -F supplierEmail=test@example.com -F invoice=@invoice.pdf http://localhost:5000/api/supplier-invoices
curl -H "Authorization: Bearer <ADMIN_TOKEN>" http://localhost:5000/api/supplier-invoices/admin/list
```
