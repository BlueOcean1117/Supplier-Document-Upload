# Supplier Invoice Portal — integration (only 2 existing-file edits)

1. Backend deps:  npm i nodemailer multer
2. Copy backend/.env.supplier-invoice.example values into backend/.env
3. backend/server.js — add next to your other app.use('/api/...') lines:
   app.use('/api/supplier-invoices', require('./modules/supplier-invoice/routes')); // ✅ NEW
4. frontend/src/App.js — add imports + routes:
   import SupplierInvoicePortal from './modules/supplier-invoice/SupplierInvoicePortal'; // ✅ NEW
   import SupplierInvoiceAdmin from './modules/supplier-invoice/SupplierInvoiceAdmin';   // ✅ NEW
   <Route path="/supplier-invoice" element={<SupplierInvoicePortal />} />          {/* ✅ NEW — public */}
   <Route path="/admin/supplier-invoices" element={<SupplierInvoiceAdmin />} />    {/* ✅ NEW — inside admin-protected wrapper */}

Checks:
- routes.js: replace `protect` / `adminOnly` import with your real admin guard.
- Render disk is ephemeral: attach a persistent disk for backend/private_uploads/.
- Gmail SMTP: use an App Password in SMTP_PASS.
